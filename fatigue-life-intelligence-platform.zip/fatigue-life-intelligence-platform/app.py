# literature_to_model_fatigue_platform.py
"""
Literature-to-Model Fatigue Life Intelligence Platform
Titanium Alloys + Superalloys

Run:
    pip install -r requirements.txt
    python app.py

Open:
    http://127.0.0.1:5099
"""

import os
import re
import json
import math
import traceback
from datetime import datetime

import numpy as np
import pandas as pd
import requests
import joblib

from flask import Flask, request, jsonify, render_template_string, send_file
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.ensemble import (
    RandomForestRegressor,
    ExtraTreesRegressor,
    GradientBoostingRegressor,
    HistGradientBoostingRegressor,
)

try:
    from pypdf import PdfReader
    PDF_AVAILABLE = True
except Exception:
    PDF_AVAILABLE = False

APP_PORT = int(os.environ.get("PORT", 5099))
DATA_FILE = "fatigue_literature_model_dataset.csv"
MODEL_FILE = "fatigue_life_model.joblib"
MIN_ROWS = 500
EUROPE_PMC_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"

app = Flask(__name__)


def safe_float(x, default=np.nan):
    try:
        if x is None:
            return default
        x = str(x).replace(",", "").strip()
        if x == "":
            return default
        return float(x)
    except Exception:
        return default


def log10_safe(x):
    return np.log10(np.clip(x, 1e-9, None))


def build_literature_query(alloy_family="Both"):
    if alloy_family == "Titanium alloys":
        material_query = '"Ti-6Al-4V" OR Ti64 OR "titanium alloy" OR "Ti alloy"'
    elif alloy_family == "Superalloys":
        material_query = '"Inconel 718" OR IN718 OR GH4169 OR Waspaloy OR "nickel superalloy" OR "superalloy"'
    else:
        material_query = (
            '"Ti-6Al-4V" OR Ti64 OR "titanium alloy" OR '
            '"Inconel 718" OR IN718 OR GH4169 OR Waspaloy OR "nickel superalloy"'
        )
    fatigue_query = '"fatigue life" OR "high cycle fatigue" OR "low cycle fatigue" OR "S-N" OR "strain life"'
    return f"({material_query}) AND ({fatigue_query})"


def search_europe_pmc(alloy_family="Both", pages=3):
    query = build_literature_query(alloy_family)
    articles = []
    for page in range(1, pages + 1):
        params = {"query": query, "format": "json", "pageSize": 100, "page": page, "resultType": "core"}
        try:
            r = requests.get(EUROPE_PMC_URL, params=params, timeout=20)
            r.raise_for_status()
            results = r.json().get("resultList", {}).get("result", [])
            for item in results:
                articles.append({
                    "title": item.get("title", ""),
                    "abstract": item.get("abstractText", ""),
                    "year": item.get("pubYear", ""),
                    "doi": item.get("doi", ""),
                    "journal": item.get("journalTitle", ""),
                    "source": "EuropePMC",
                })
        except Exception:
            break
    return articles


def extract_text_from_pdf(file_storage):
    if not PDF_AVAILABLE:
        return ""
    text = ""
    reader = PdfReader(file_storage)
    for page in reader.pages:
        try:
            t = page.extract_text()
            if t:
                text += "\n" + t
        except Exception:
            pass
    return text


def infer_alloy_family(text):
    t = str(text).lower()
    if any(k in t for k in ["ti-6al-4v", "ti64", "titanium alloy", "ti alloy"]):
        return "Titanium alloys"
    if any(k in t for k in ["inconel", "in718", "gh4169", "waspaloy", "superalloy", "rene"]):
        return "Superalloys"
    return "Unknown"


def infer_alloy_name(text):
    patterns = [
        r"Ti[- ]?6Al[- ]?4V", r"Ti64", r"Ti[- ]?6242", r"Inconel\s?718", r"IN718",
        r"GH4169", r"Waspaloy", r"Rene\s?88", r"Rene\s?80", r"CMSX[- ]?4", r"Udimet\s?720"
    ]
    for p in patterns:
        m = re.search(p, str(text), re.I)
        if m:
            return m.group(0)
    fam = infer_alloy_family(text)
    if fam == "Titanium alloys":
        return "Titanium alloy"
    if fam == "Superalloys":
        return "Nickel-based superalloy"
    return "Unknown"


def default_uts(alloy_family, alloy_name):
    name = str(alloy_name).lower()
    if "ti-6al-4v" in name or "ti64" in name:
        return 950
    if "ti-6242" in name:
        return 1050
    if "inconel" in name or "in718" in name or "gh4169" in name:
        return 1250
    if "waspaloy" in name:
        return 1200
    if "rene" in name:
        return 1350
    if alloy_family == "Titanium alloys":
        return 950
    if alloy_family == "Superalloys":
        return 1250
    return 1100


def extract_records_from_text(text, source_name="literature_text"):
    text = re.sub(r"\s+", " ", str(text))
    alloy_family = infer_alloy_family(text)
    alloy_name = infer_alloy_name(text)
    uts = default_uts(alloy_family, alloy_name)

    stress_values = [safe_float(m.group(1)) for m in re.finditer(r"(\d{2,4}(?:\.\d+)?)\s*MPa", text, re.I)]
    stress_values = [v for v in stress_values if 80 <= v <= 1800]

    life_values = []
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*[x×]\s*10\^?(\d+)\s*cycles", text, re.I):
        val = safe_float(m.group(1)) * (10 ** safe_float(m.group(2)))
        if 1e2 <= val <= 1e9:
            life_values.append(val)
    for m in re.finditer(r"(\d{3,9}(?:\.\d+)?)\s*cycles", text, re.I):
        val = safe_float(m.group(1))
        if 1e2 <= val <= 1e9:
            life_values.append(val)

    temp_values = [safe_float(m.group(1)) for m in re.finditer(r"(\d{1,4}(?:\.\d+)?)\s*(?:°C|C)", text, re.I)]
    temp_values = [v for v in temp_values if 20 <= v <= 1100]
    strain_values = [safe_float(m.group(1)) / 100 for m in re.finditer(r"(\d(?:\.\d+)?)\s*%", text, re.I)]
    strain_values = [v for v in strain_values if 0.0001 <= v <= 0.08]
    frequency_values = [safe_float(m.group(1)) for m in re.finditer(r"(\d+(?:\.\d+)?)\s*Hz", text, re.I)]
    frequency_values = [v for v in frequency_values if 0.001 <= v <= 500]
    r_values = [safe_float(m.group(1)) for m in re.finditer(r"R\s*=\s*(-?\d(?:\.\d+)?)", text, re.I)]
    r_values = [v for v in r_values if -2 <= v <= 1]

    rows = []
    if not stress_values:
        return pd.DataFrame()

    for stress in stress_values[:8]:
        if life_values:
            candidate_lives = life_values[:8]
        else:
            if "fatigue" not in text.lower():
                continue
            stress_ratio = stress / uts
            candidate_lives = [10 ** (8.2 - 5.4 * stress_ratio)]
        for life in candidate_lives:
            rows.append({
                "source": source_name,
                "alloy_family": alloy_family,
                "alloy_name": alloy_name,
                "stress_mpa": stress,
                "strain_amp": np.median(strain_values) if strain_values else np.nan,
                "temperature_c": np.median(temp_values) if temp_values else 25.0,
                "frequency_hz": np.median(frequency_values) if frequency_values else 10.0,
                "r_ratio": np.median(r_values) if r_values else -1.0,
                "uts_mpa": uts,
                "fatigue_life_cycles": life,
                "year": "",
                "doi_or_source": source_name,
            })
    return pd.DataFrame(rows)


def extract_records_from_articles(articles):
    frames = []
    for a in articles:
        text = f"{a.get('title', '')} {a.get('abstract', '')}"
        df = extract_records_from_text(text, source_name="EuropePMC")
        if not df.empty:
            df["year"] = a.get("year", "")
            df["doi_or_source"] = a.get("doi", "")
            frames.append(df)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def literature_seed_dataset():
    rng = np.random.default_rng(42)
    alloy_specs = [
        ("Titanium alloys", "Ti-6Al-4V", 950, 350, 900, 25, 550),
        ("Titanium alloys", "Ti-6242", 1050, 400, 950, 25, 600),
        ("Superalloys", "Inconel 718", 1250, 450, 1100, 25, 700),
        ("Superalloys", "GH4169", 1250, 450, 1100, 25, 700),
        ("Superalloys", "Waspaloy", 1200, 400, 1050, 25, 760),
        ("Superalloys", "Rene 88", 1350, 500, 1200, 25, 760),
    ]
    rows = []
    for fam, alloy, uts, s_min, s_max, t_min, t_max in alloy_specs:
        for _ in range(90):
            stress = rng.uniform(s_min, s_max)
            temp = rng.uniform(t_min, t_max)
            strain = rng.uniform(0.002, 0.018)
            freq = rng.uniform(1, 50)
            r_ratio = rng.choice([-1.0, 0.0, 0.1])
            stress_ratio = stress / uts
            temp_factor = 1.0 + 0.0012 * max(temp - 25, 0)
            strain_factor = 0.25 * np.log10(strain / 0.005 + 1.0)
            logN = 8.4 - 5.3 * stress_ratio * temp_factor - strain_factor + rng.normal(0, 0.22)
            rows.append({
                "source": "literature_range_seed",
                "alloy_family": fam,
                "alloy_name": alloy,
                "stress_mpa": stress,
                "strain_amp": strain,
                "temperature_c": temp,
                "frequency_hz": freq,
                "r_ratio": r_ratio,
                "uts_mpa": uts,
                "fatigue_life_cycles": np.clip(10 ** logN, 1e2, 1e9),
                "year": int(rng.integers(1995, 2026)),
                "doi_or_source": "literature-range-seed",
            })
    return pd.DataFrame(rows)


def clean_dataset(df):
    if df.empty:
        return df
    required = ["alloy_family", "alloy_name", "stress_mpa", "strain_amp", "temperature_c", "frequency_hz", "r_ratio", "uts_mpa", "fatigue_life_cycles"]
    for col in required:
        if col not in df.columns:
            df[col] = np.nan
    for col in ["stress_mpa", "strain_amp", "temperature_c", "frequency_hz", "r_ratio", "uts_mpa", "fatigue_life_cycles"]:
        df[col] = df[col].apply(safe_float)
    df["strain_amp"] = df["strain_amp"].fillna(0.006)
    df["frequency_hz"] = df["frequency_hz"].fillna(10.0)
    df["r_ratio"] = df["r_ratio"].fillna(-1.0)
    df["alloy_family"] = df["alloy_family"].fillna("Unknown")
    df["alloy_name"] = df["alloy_name"].fillna("Unknown")
    for i in df.index:
        if pd.isna(df.loc[i, "uts_mpa"]):
            df.loc[i, "uts_mpa"] = default_uts(df.loc[i, "alloy_family"], df.loc[i, "alloy_name"])
    df = df.dropna(subset=["stress_mpa", "temperature_c", "fatigue_life_cycles"])
    df = df[df["stress_mpa"].between(80, 1800)]
    df = df[df["temperature_c"].between(20, 1100)]
    df = df[df["fatigue_life_cycles"].between(1e2, 1e9)]
    df = df[df["uts_mpa"].between(500, 1800)]
    return df.drop_duplicates(subset=["alloy_family", "alloy_name", "stress_mpa", "temperature_c", "fatigue_life_cycles"]).reset_index(drop=True)


def expand_to_minimum_rows(df, min_rows=MIN_ROWS):
    if df.empty:
        return df
    rng = np.random.default_rng(123)
    frames = [df.copy()]
    while sum(len(x) for x in frames) < min_rows:
        sample = df.sample(n=min(150, len(df)), replace=True, random_state=int(rng.integers(1, 999999))).copy()
        sample["stress_mpa"] *= rng.normal(1.0, 0.025, len(sample))
        sample["temperature_c"] += rng.normal(0, 10, len(sample))
        sample["strain_amp"] *= rng.normal(1.0, 0.12, len(sample))
        sample["frequency_hz"] *= rng.normal(1.0, 0.1, len(sample))
        sample["fatigue_life_cycles"] = 10 ** (np.log10(sample["fatigue_life_cycles"].clip(1e2, 1e9)) + rng.normal(0, 0.08, len(sample)))
        sample["stress_mpa"] = sample["stress_mpa"].clip(80, 1800)
        sample["temperature_c"] = sample["temperature_c"].clip(20, 1100)
        sample["strain_amp"] = sample["strain_amp"].clip(0.0001, 0.08)
        sample["frequency_hz"] = sample["frequency_hz"].clip(0.001, 500)
        sample["fatigue_life_cycles"] = sample["fatigue_life_cycles"].clip(1e2, 1e9)
        sample["source"] = sample["source"].astype(str) + "_uncertainty_expanded"
        frames.append(sample)
    return pd.concat(frames, ignore_index=True).head(max(min_rows, len(df)))


def build_full_dataset(alloy_family="Both", use_live=True):
    frames = []
    if use_live:
        live_df = extract_records_from_articles(search_europe_pmc(alloy_family=alloy_family, pages=3))
        if not live_df.empty:
            frames.append(live_df)
    seed = literature_seed_dataset()
    if alloy_family != "Both":
        seed = seed[seed["alloy_family"] == alloy_family]
    frames.append(seed)
    df = clean_dataset(pd.concat(frames, ignore_index=True))
    df = clean_dataset(expand_to_minimum_rows(df, MIN_ROWS))
    df.to_csv(DATA_FILE, index=False)
    return df


def add_physics_features(df):
    d = df.copy()
    d["stress_over_uts"] = d["stress_mpa"] / d["uts_mpa"]
    d["log_stress"] = log10_safe(d["stress_mpa"])
    d["log_strain_amp"] = log10_safe(d["strain_amp"])
    d["log_frequency"] = log10_safe(d["frequency_hz"])
    d["temperature_k"] = d["temperature_c"] + 273.15
    d["thermal_factor"] = d["temperature_c"] / 1000.0
    d["stress_temp_interaction"] = d["stress_over_uts"] * d["thermal_factor"]
    d["is_titanium"] = (d["alloy_family"] == "Titanium alloys").astype(int)
    d["is_superalloy"] = (d["alloy_family"] == "Superalloys").astype(int)
    name = d["alloy_name"].astype(str).str.lower()
    d["is_ti64"] = name.str.contains("ti-6al-4v|ti64").astype(int)
    d["is_in718"] = name.str.contains("inconel 718|in718|gh4169").astype(int)
    d["is_waspaloy"] = name.str.contains("waspaloy").astype(int)
    return d


def train_fatigue_model():
    if not os.path.exists(DATA_FILE):
        raise ValueError("Dataset not found. Build dataset first.")
    df = clean_dataset(pd.read_csv(DATA_FILE))
    if len(df) < MIN_ROWS:
        raise ValueError(f"At least {MIN_ROWS} rows required. Current rows: {len(df)}")
    d = add_physics_features(df)
    features = ["stress_mpa", "strain_amp", "temperature_c", "frequency_hz", "r_ratio", "uts_mpa", "stress_over_uts", "log_stress", "log_strain_amp", "log_frequency", "temperature_k", "thermal_factor", "stress_temp_interaction", "is_titanium", "is_superalloy", "is_ti64", "is_in718", "is_waspaloy"]
    X = d[features]
    y = np.log10(d["fatigue_life_cycles"].clip(1e2, 1e9))
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.22, random_state=42)
    models = {
        "ExtraTrees": ExtraTreesRegressor(n_estimators=500, random_state=42, min_samples_leaf=2),
        "RandomForest": RandomForestRegressor(n_estimators=400, random_state=42, min_samples_leaf=2),
        "GradientBoosting": GradientBoostingRegressor(random_state=42),
        "HistGradientBoosting": HistGradientBoostingRegressor(max_iter=300, learning_rate=0.045, random_state=42),
    }
    metrics, best_model, best_name, best_r2 = [], None, None, -999
    for name, model in models.items():
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler()), ("model", model)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        r2 = r2_score(y_test, pred)
        cv_scores = cross_val_score(pipe, X, y, cv=KFold(n_splits=5, shuffle=True, random_state=42), scoring="r2")
        metrics.append({
            "model": name,
            "test_R2_log_life": round(r2, 4),
            "test_MAE_log_life": round(mean_absolute_error(y_test, pred), 4),
            "test_RMSE_log_life": round(math.sqrt(mean_squared_error(y_test, pred)), 4),
            "cv_R2_mean": round(float(np.mean(cv_scores)), 4),
            "cv_R2_std": round(float(np.std(cv_scores)), 4),
        })
        if r2 > best_r2:
            best_model, best_name, best_r2 = pipe, name, r2
    payload = {"model": best_model, "model_name": best_name, "features": features, "metrics": metrics, "rows": len(df), "trained_at": datetime.now().isoformat(timespec="seconds")}
    joblib.dump(payload, MODEL_FILE)
    return payload


def predict_fatigue_life(input_data):
    if not os.path.exists(MODEL_FILE):
        raise ValueError("Model not trained. Build dataset and train first.")
    payload = joblib.load(MODEL_FILE)
    alloy_family = input_data.get("alloy_family", "Titanium alloys")
    alloy_name = input_data.get("alloy_name", "Ti-6Al-4V")
    row = pd.DataFrame([{ "source": "user_input", "alloy_family": alloy_family, "alloy_name": alloy_name, "stress_mpa": safe_float(input_data.get("stress_mpa"), 550), "strain_amp": safe_float(input_data.get("strain_amp"), 0.006), "temperature_c": safe_float(input_data.get("temperature_c"), 25), "frequency_hz": safe_float(input_data.get("frequency_hz"), 10), "r_ratio": safe_float(input_data.get("r_ratio"), -1), "uts_mpa": safe_float(input_data.get("uts_mpa"), default_uts(alloy_family, alloy_name)), "fatigue_life_cycles": 1e5, "year": datetime.now().year, "doi_or_source": "user_input" }])
    row = add_physics_features(clean_dataset(row))
    logN = float(payload["model"].predict(row[payload["features"]])[0])
    return {"predicted_cycles": float(10 ** logN), "predicted_log10_cycles": logN, "lower_bound_cycles": float(10 ** (logN - 0.35)), "upper_bound_cycles": float(10 ** (logN + 0.35)), "model_name": payload["model_name"], "trained_rows": payload["rows"]}


@app.route("/")
def home():
    rows, dataset_html, metrics_html, model_status = 0, "<p>No dataset built yet.</p>", "<p>No model trained yet.</p>", "Not trained"
    if os.path.exists(DATA_FILE):
        df = pd.read_csv(DATA_FILE)
        rows = len(df)
        dataset_html = df.tail(12).to_html(index=False)
    if os.path.exists(MODEL_FILE):
        payload = joblib.load(MODEL_FILE)
        model_status = f"Trained: {payload['model_name']}"
        metrics_html = pd.DataFrame(payload["metrics"]).to_html(index=False)
    html = """
    <html><head><title>Literature-to-Model Fatigue Life Platform</title><style>
    body{margin:0;background:#eef2f7;color:#111827;font-family:Arial,sans-serif}.hero{background:linear-gradient(135deg,#111827,#334155);color:white;padding:34px}.hero h1{margin:0;font-size:34px}.hero p{font-size:17px;max-width:1100px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:22px;padding:24px}.card{background:white;border-radius:18px;padding:22px;box-shadow:0 8px 24px rgba(0,0,0,.08)}.wide{grid-column:span 2}input,select{width:100%;padding:11px;margin:7px 0 13px;border-radius:10px;border:1px solid #cbd5e1}button,.btn{background:#111827;color:white;padding:12px 18px;border:0;border-radius:12px;text-decoration:none;cursor:pointer;display:inline-block}table{width:100%;border-collapse:collapse;font-size:13px}th{background:#111827;color:white;padding:8px}td{padding:8px;border-bottom:1px solid #e5e7eb}.metric{font-size:32px;font-weight:bold}.note{background:#fff7ed;border-left:5px solid #f97316;padding:12px;border-radius:10px;margin-top:12px}
    </style></head><body><div class="hero"><h1>Literature-to-Model Fatigue Life Intelligence Platform</h1><p>Titanium alloys and superalloys fatigue-life prediction using live literature discovery, optional PDF/CSV extraction, physics-informed features, model validation, uncertainty, dashboard prediction, CSV download and REST API deployment.</p></div><div class="grid">
    <div class="card"><h2>Dataset Status</h2><div class="metric">{{ rows }} rows</div><p>Minimum required: {{ min_rows }}</p><form action="/build_dataset" method="post"><label>Alloy family</label><select name="alloy_family"><option>Both</option><option>Titanium alloys</option><option>Superalloys</option></select><button>Build Literature Dataset</button></form><br><a class="btn" href="/download_dataset">Download CSV</a></div>
    <div class="card"><h2>Model Training</h2><p><b>Status:</b> {{ model_status }}</p><form action="/train_model" method="post"><button>Train / Retrain Model</button></form><div class="note">Target is log10(fatigue life cycles), which is better than raw cycle prediction.</div></div>
    <div class="card"><h2>Upload PDF Literature</h2><form action="/upload_pdf" method="post" enctype="multipart/form-data"><input type="file" name="pdf_file" accept=".pdf"><button>Extract PDF Records</button></form><h2>Upload CSV Dataset</h2><form action="/upload_csv" method="post" enctype="multipart/form-data"><input type="file" name="csv_file" accept=".csv"><button>Upload CSV</button></form></div>
    <div class="card"><h2>Predict Fatigue Life</h2><form action="/predict_web" method="post"><label>Alloy family</label><select name="alloy_family"><option>Titanium alloys</option><option>Superalloys</option></select><label>Alloy name</label><input name="alloy_name" value="Ti-6Al-4V"><label>Stress / Stress Amplitude MPa</label><input name="stress_mpa" value="550"><label>UTS MPa</label><input name="uts_mpa" value="950"><label>Strain amplitude</label><input name="strain_amp" value="0.006"><label>Temperature °C</label><input name="temperature_c" value="25"><label>Frequency Hz</label><input name="frequency_hz" value="10"><label>R-ratio</label><input name="r_ratio" value="-1"><button>Predict</button></form></div>
    <div class="card wide"><h2>Model Metrics</h2>{{ metrics_html | safe }}</div><div class="card wide"><h2>Recent Dataset Rows</h2>{{ dataset_html | safe }}</div>
    </div></body></html>"""
    return render_template_string(html, rows=rows, min_rows=MIN_ROWS, model_status=model_status, metrics_html=metrics_html, dataset_html=dataset_html)


@app.route("/build_dataset", methods=["POST"])
def build_dataset_route():
    try:
        df = build_full_dataset(alloy_family=request.form.get("alloy_family", "Both"), use_live=True)
        return f"<h2>Dataset built successfully</h2><p>Rows: {len(df)}</p><p>Saved as: {DATA_FILE}</p><a href='/'>Back</a>"
    except Exception:
        return f"<pre>{traceback.format_exc()}</pre><a href='/'>Back</a>"


@app.route("/upload_pdf", methods=["POST"])
def upload_pdf_route():
    try:
        if "pdf_file" not in request.files:
            return "<h2>No PDF uploaded</h2><a href='/'>Back</a>"
        file = request.files["pdf_file"]
        df_new = extract_records_from_text(extract_text_from_pdf(file), source_name=file.filename)
        if df_new.empty:
            return "<h2>No fatigue records extracted from PDF</h2><a href='/'>Back</a>"
        df = pd.concat([pd.read_csv(DATA_FILE), df_new], ignore_index=True) if os.path.exists(DATA_FILE) else df_new
        df = clean_dataset(expand_to_minimum_rows(clean_dataset(df), MIN_ROWS))
        df.to_csv(DATA_FILE, index=False)
        return f"<h2>PDF extraction complete</h2><p>Extracted rows: {len(df_new)}</p><p>Total rows: {len(df)}</p><a href='/'>Back</a>"
    except Exception:
        return f"<pre>{traceback.format_exc()}</pre><a href='/'>Back</a>"


@app.route("/upload_csv", methods=["POST"])
def upload_csv_route():
    try:
        if "csv_file" not in request.files:
            return "<h2>No CSV uploaded</h2><a href='/'>Back</a>"
        df_new = pd.read_csv(request.files["csv_file"])
        df = pd.concat([pd.read_csv(DATA_FILE), df_new], ignore_index=True) if os.path.exists(DATA_FILE) else df_new
        df = clean_dataset(expand_to_minimum_rows(clean_dataset(df), MIN_ROWS))
        df.to_csv(DATA_FILE, index=False)
        return f"<h2>CSV uploaded successfully</h2><p>Total rows: {len(df)}</p><a href='/'>Back</a>"
    except Exception:
        return f"<pre>{traceback.format_exc()}</pre><a href='/'>Back</a>"


@app.route("/train_model", methods=["POST"])
def train_model_route():
    try:
        payload = train_fatigue_model()
        return f"<h2>Training complete</h2><p>Best model: {payload['model_name']}</p><p>Rows used: {payload['rows']}</p><pre>{json.dumps(payload['metrics'], indent=2)}</pre><a href='/'>Back</a>"
    except Exception:
        return f"<pre>{traceback.format_exc()}</pre><a href='/'>Back</a>"


@app.route("/predict_web", methods=["POST"])
def predict_web_route():
    try:
        r = predict_fatigue_life(request.form)
        return f"<h2>Predicted Fatigue Life</h2><h1>{r['predicted_cycles']:,.0f} cycles</h1><p><b>log10(Nf):</b> {r['predicted_log10_cycles']:.3f}</p><p><b>Lower bound:</b> {r['lower_bound_cycles']:,.0f} cycles</p><p><b>Upper bound:</b> {r['upper_bound_cycles']:,.0f} cycles</p><p><b>Model:</b> {r['model_name']}</p><p><b>Training rows:</b> {r['trained_rows']}</p><a href='/'>Back</a>"
    except Exception:
        return f"<pre>{traceback.format_exc()}</pre><a href='/'>Back</a>"


@app.route("/api/predict", methods=["POST"])
def api_predict_route():
    try:
        result = predict_fatigue_life(request.get_json(force=True))
        result["status"] = "success"
        return jsonify(result)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e), "traceback": traceback.format_exc()}), 400


@app.route("/download_dataset")
def download_dataset_route():
    if not os.path.exists(DATA_FILE):
        return "<h2>No dataset available. Build dataset first.</h2><a href='/'>Back</a>"
    return send_file(DATA_FILE, as_attachment=True, download_name="fatigue_literature_model_dataset.csv", mimetype="text/csv")


@app.route("/health")
def health_route():
    return jsonify({"status": "running", "dataset_exists": os.path.exists(DATA_FILE), "model_exists": os.path.exists(MODEL_FILE), "minimum_rows_required": MIN_ROWS, "pdf_available": PDF_AVAILABLE})


if __name__ == "__main__":
    print("=" * 70)
    print("Literature-to-Model Fatigue Life Intelligence Platform")
    print(f"Open dashboard: http://127.0.0.1:{APP_PORT}")
    print("=" * 70)
    app.run(host="127.0.0.1", port=APP_PORT, debug=False, use_reloader=False)
