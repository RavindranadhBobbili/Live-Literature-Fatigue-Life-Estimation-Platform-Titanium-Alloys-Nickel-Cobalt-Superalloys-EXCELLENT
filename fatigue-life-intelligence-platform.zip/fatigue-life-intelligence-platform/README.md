# Literature-to-Model Fatigue Life Intelligence Platform

A deployable Flask dashboard for fatigue-life estimation of **titanium alloys** and **nickel/cobalt superalloys** using literature discovery, PDF/CSV ingestion, physics-informed feature engineering, model validation, uncertainty bands, CSV download, and REST API prediction.

## Key Features

- Live literature discovery through Europe PMC metadata/abstract search
- Optional PDF upload and text extraction
- Optional CSV upload for validated fatigue data
- Minimum 500-row dataset enforcement
- Titanium alloys and superalloys support
- Physics-informed features:
  - stress / UTS
  - log stress
  - log strain amplitude
  - temperature factor
  - stress-temperature interaction
  - R-ratio
  - frequency
- Model comparison:
  - ExtraTrees
  - RandomForest
  - GradientBoosting
  - HistGradientBoosting
- Predicts `log10(Nf)` and converts to fatigue-life cycles
- Uncertainty band for engineering interpretation
- Download dataset as CSV
- REST API endpoint `/api/predict`

## Quick Start

```bash
pip install -r requirements.txt
python app.py
```

Open:

```text
http://127.0.0.1:5099
```

## Dashboard Workflow

1. Build Literature Dataset
2. Train / Retrain Model
3. Predict Fatigue Life
4. Download CSV if needed

## API Example

```bash
curl -X POST http://127.0.0.1:5099/api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "alloy_family": "Titanium alloys",
    "alloy_name": "Ti-6Al-4V",
    "stress_mpa": 550,
    "uts_mpa": 950,
    "strain_amp": 0.006,
    "temperature_c": 25,
    "frequency_hz": 10,
    "r_ratio": -1
  }'
```

## Expected CSV Columns

If uploading your own fatigue dataset, include these columns when possible:

```text
alloy_family, alloy_name, stress_mpa, strain_amp, temperature_c,
frequency_hz, r_ratio, uts_mpa, fatigue_life_cycles, source, year, doi_or_source
```

The app can fill some missing fields, but better metadata improves model performance.

## Important Scientific Note

This project is a **portfolio-ready literature-to-model platform**. For publication-grade performance, replace or extend the seed rows with manually validated or table-extracted fatigue data from S-N/LCF experimental papers, NIMS fatigue data sheets, NASA/NTRS reports, and open fatigue datasets.

## Suggested Repository Description

> Literature-to-model fatigue life prediction platform for titanium alloys and superalloys using live literature discovery, PDF/CSV extraction, physics-informed ML, dashboard deployment, uncertainty and REST API.

## License

MIT License.
