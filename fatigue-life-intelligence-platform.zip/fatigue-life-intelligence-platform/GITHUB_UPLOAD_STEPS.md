# GitHub Upload Steps

## Option 1: Upload through GitHub website

1. Create a new repository on GitHub.
2. Name it: `literature-to-model-fatigue-life-platform`.
3. Upload all files from this folder.
4. Add repository description:

```text
Literature-to-model fatigue life prediction platform for titanium alloys and superalloys using live literature discovery, PDF/CSV extraction, physics-informed ML, dashboard deployment, uncertainty and REST API.
```

## Option 2: Upload using Git command line

```bash
git init
git add .
git commit -m "Initial commit: fatigue life intelligence platform"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/literature-to-model-fatigue-life-platform.git
git push -u origin main
```

## Recommended GitHub Topics

```text
materials-informatics
fatigue-life
machine-learning
superalloys
titanium-alloys
flask-dashboard
physics-informed-ml
literature-mining
materials-science
api-deployment
```
